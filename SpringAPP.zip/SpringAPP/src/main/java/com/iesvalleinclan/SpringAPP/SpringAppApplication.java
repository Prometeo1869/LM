package com.iesvalleinclan.SpringAPP;

import org.springframework.boot.autoconfigure.*;
import org.springframework.boot.*;

@SpringBootApplication
public class SpringAppApplication {

	public static void main(String[] args) {

		SpringApplication.run(SpringAppApplication.class, args);

	}

}
